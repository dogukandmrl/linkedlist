
package _18010310052_dogukan_demirel;

import java.io.File;
import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.util.Scanner;


public class _18010310052_Dogukan_Demirel {

   
    public static void main(String[] args)  {
        //bagli liste oluşturacağım classı tanımladım 5000 adet veriyi okutacağım için bir sayac ve 5000 verinin yer alacağı veritipini tanımladım
        _18010310052_bagliliste _18010310052_Bagliliste = new _18010310052_bagliliste();
        int sayac= 0;
        int veri_sayisi=5000;
     try
     {
         File dosya = new File("kayit_dosyasi.txt"); //tckimlik isim soyisim gibi verileri kayit_dosyas.txt'den çekmesi için dosyayı tanımladım
         Scanner okuyucu = new Scanner(dosya); // dosyanın içindeki verileri okuması için scanner tanımladım
         while(okuyucu.hasNextLine()&& sayac < veri_sayisi)
         {
             String veri = okuyucu.nextLine();               // try komutunun veri sayisi kadar veri okuması için while komutu kullandım
             String[] split =veri.split(",");
             _18010310052_Bagliliste.Insert(new _18010310052_kayit(new BigDecimal(split[0]),split[1],split[2])); //verileri bölüp alt alta yazdırması için split yapısını kullandım
             sayac++;
             
          
         }
         okuyucu.close();
            
     }catch(FileNotFoundException e)
     {
         System.out.println("hata oluştu");  // try komutu dışında hata verirse hata mesajı vermesi için catch komutunu yazdım.
         e.printStackTrace();
     }
     //üretilen kaydı ve silinen eski kaydı yazdırır.
        System.out.println("Silinen Numara:"+ _18010310052_Bagliliste.Delete(new BigDecimal("9249319882")));
        System.out.println("Kayit no:" + _18010310052_Bagliliste.Return_Kayit());
        _18010310052_Bagliliste.Insert(new _18010310052_kayit(new BigDecimal("3133695875"),"egqdqxjaeg","ogyzpecfqy"));  
        System.out.println("Kayit no:"+ _18010310052_Bagliliste.Return_Kayit());
        
        long basla_zaman= System.nanoTime();
        _18010310052_kayit _18010310052_kayit = _18010310052_Bagliliste.Search(new BigDecimal("1951826353"));
        long bitis_zaman= System.nanoTime(); //kodun başlama ve bitiş zamanını geçen süreyi yazdırmak için nanotime yapısını kullandım
        
        long gecen_sure= bitis_zaman - basla_zaman; //bitis ve baslangıc zamanından çıkararak başlangıç zamanını yazdırdım.
        System.out.println("Süre: "+gecen_sure / 1000000 + "milisaniye");
        _18010310052_Bagliliste.yazdir(_18010310052_kayit);
        
        _18010310052_kayit = _18010310052_Bagliliste.Return_Kayit(1); //split ile böldüğüm verileri yazdırmak için bu komutu kullandım
        _18010310052_Bagliliste.yazdir(_18010310052_kayit);
        
        _18010310052_kayit= _18010310052_Bagliliste.Return_Kayit(2);
        _18010310052_Bagliliste.yazdir(_18010310052_kayit);
        
        
        
        
        
        
        
        
    }
    
}
