
package _18010310052_dogukan_demirel;

import java.math.BigDecimal;


public class _18010310052_bagliliste {
        private _18010310052_kayit ilk_kayit;


    void Insert(_18010310052_kayit kayit) {   // eğer tc kimlik alanı boşsa kayit nesnesi bağlantıı listeye ekler
        if (ilk_kayit == null) {
            ilk_kayit = kayit;
            return;
        }
        //ilk değerler verilir
        _18010310052_kayit gosterge = null;
        _18010310052_kayit siradaki_kayit = ilk_kayit;
        int sira = 0;

        // kaydın listede ekleneceği yer aranır 
        while (siradaki_kayit != null && siradaki_kayit.gettc_kimlik().compareTo(kayit.gettc_kimlik()) <= 0) {
            // tc kimlik değişkeninden sonra bir değişken daha ekleneceği için sıra 1 artar.
            siradaki_kayit.setkalan_sira_no(siradaki_kayit.getkalan_sira_no() + 1);
            gosterge = siradaki_kayit;
            siradaki_kayit = siradaki_kayit.getNext_18010310052_kayit();
            sira++;
        }

        kayit.setNextKayit(siradaki_kayit);
        kayit.setsira_no(sira);

    
        //eğer sonuncu kayıt aranan kayıt değilse bir sonraki kayıt atanır eğer sonuncu ise varsayılan olarak devam eder
        if (siradaki_kayit != null) {
            kayit.setkalan_sira_no(siradaki_kayit.getkalan_sira_no() + 1);
        }

        
        // eğer gösterge null sonuç verirse aranan kayıt ilk elemana eklenir.
        if (gosterge == null) {
            ilk_kayit = kayit;
        } else {
            gosterge.setNextKayit(kayit);
        }

      
        //eklendikten sonra kayıt aranırken oluşturualın sıralar düzenlenir.
        while (siradaki_kayit != null) {
            sira++;
            siradaki_kayit.setsira_no(sira);
            siradaki_kayit = siradaki_kayit.getNext_18010310052_kayit();
        }
    }

    
    
    _18010310052_kayit Search(BigDecimal tcKimlikNo) {
        _18010310052_kayit gosterge = ilk_kayit;
//tc kimlik no parametresini listede arar
        while (gosterge != null && gosterge.gettc_kimlik().compareTo(tcKimlikNo) <= 0) {
            if (gosterge.gettc_kimlik().equals(tcKimlikNo)) {
                return gosterge;
            } //eğer bulursa node döndürür
            gosterge = gosterge.getNext_18010310052_kayit();
        }

        return null; //bulamazsa null döndürür
    }

  
   _18010310052_kayit Return_Kayit(int sirasi) {
        if (sirasi < 0 || sirasi > ilk_kayit.getkalan_sira_no()) {
            return null;     //listede sırası verilen kayıt listenin dışındaysa null dönddürür
        }

        _18010310052_kayit gosterge = ilk_kayit;

        while (gosterge.getsira_no() != sirasi) {
            gosterge = gosterge.getNext_18010310052_kayit();
        }
        return gosterge;
    }

  
    int Delete(BigDecimal tcKimlikNo) {
        _18010310052_kayit gosterge = null;
        _18010310052_kayit siradaki = ilk_kayit;

        while (siradaki != null && siradaki.gettc_kimlik().compareTo(tcKimlikNo) <= 0) {
            if (siradaki.gettc_kimlik().equals(tcKimlikNo)) {
                _18010310052_kayit gosterge2 = ilk_kayit;   //tc kimlik numarası eğer listede varsa o silinir ve tc kimlik sırası döndürülür.
                while (gosterge2 != null) {
                    //silinen kayıttan önceki sıra 1 eksiltirelek silinir
                    if (gosterge2.getsira_no() < siradaki.getsira_no()) {
                        gosterge2.setkalan_sira_no(gosterge2.getkalan_sira_no() - 1);
                    }

                    //silinen kayıttan sonraki 1 sıra eksiltilere silinir
                    if (gosterge2.getsira_no()> siradaki.getsira_no()){
                        gosterge2.setsira_no(gosterge2.getsira_no() - 1);
                    }

                    gosterge2 = gosterge2.getNext_18010310052_kayit();
                }

                // kayıt silme işlemi gerçekleşir
                if (gosterge == null) {
                   ilk_kayit = siradaki.getNext_18010310052_kayit();
                } else {
                    gosterge.setNextKayit(siradaki.getNext_18010310052_kayit());
                }

                return siradaki.getsira_no();
            }

            gosterge = siradaki;
            siradaki = siradaki.getNext_18010310052_kayit();
        }

        return -1; // yoksa eğer -1 döndürülür
    }

   
    int Return_Kayit() {
        if (ilk_kayit != null) { // boş mu kontrolü
            return ilk_kayit.getkalan_sira_no() + 1; //listede kaç tane kayıt varsa döndürür
        }
        return 0;
    }

    
    void yazdir(_18010310052_kayit kayit) {
        if (kayit != null) {
            System.out.println(
                    "Tc Kimlik No: " + kayit.gettc_kimlik()
                            + " Ad: " + kayit.getisim() 
                            + " Soyad: " + kayit.getsoyisim() // eğer varsa tc kimlik isim soyisim parameterelerini yazdırır yoksa boş kayıt olarak döndürür
            );
        }else {
            System.out.println("Boş kayıt");
        }

    }


}
 

