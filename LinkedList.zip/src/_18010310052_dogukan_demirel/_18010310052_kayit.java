
package _18010310052_dogukan_demirel;

import java.math.BigDecimal;


public class _18010310052_kayit {

   private BigDecimal tc_kimlik;
   private int sira_no;
   private int kalan_sira_no;
   private String isim;
   private String soyisim; //kullanacağım parametreleri tanımladım
   
   private _18010310052_kayit next_18010310052_kayit;
   public _18010310052_kayit(BigDecimal tc_kimlik, String isim, String soyisim) 
   {
     this.tc_kimlik = tc_kimlik;
     this.isim = isim;      //this ile class nesnesi tanımladım
     this.soyisim = soyisim;
   }
   /*
   tc kimlik isim soyisim sıra numarası ve gkalan sıra numarasını döndüren constructor yapıları tanımladım
   */
   public BigDecimal gettc_kimlik() 
   {
       return tc_kimlik;
   }
   public String getisim() 
   {
       return isim;
   }
   public String getsoyisim()
   {
       return soyisim;
   }
   public int getsira_no() {
        return sira_no;
    }

    public void setsira_no(int sira_no) {
        this.sira_no = sira_no;
    }

    public int getkalan_sira_no() {
        return kalan_sira_no;
    }

    public void setkalan_sira_no(int kalan_sira_no) {
        this.kalan_sira_no = kalan_sira_no;
    }

    public _18010310052_kayit getNext_18010310052_kayit() {
        return next_18010310052_kayit;
    }

    public void setNextKayit(_18010310052_kayit next_18010310052_kayit) {
        this.next_18010310052_kayit= next_18010310052_kayit;
    }
   
  
   
   
}
